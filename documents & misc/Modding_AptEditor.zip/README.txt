To convert a file you have two options:
     1. You drag and drop the file onto the icon of the executable. 
	If the convertion was succesfully you should see a message saying that
     2.	You start the application and write the filename (or drag and drop) into the console.
	To start the converter you need to press enter.
	
Valid files you can specify are .xml files or .apt files. 
WARNING: The tool will overwrite any existing files without asking for your permission!

For any questions/problems visit the official thread of this tool:
http://forum.modding-union.com/index.php/topic,28244.msg359276.html#msg359276

I'd be happy if you could mention me in the credits, but it is not a must :)